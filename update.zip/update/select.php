<?php
 if(isset($_POST["employee_id"]))
 {
      $output = '';
      $connect = mysqli_connect("localhost", "root", "", "kadpoly_ctve");
      $query = "SELECT * FROM tbl_employee WHERE id = '".$_POST["employee_id"]."'";
      $result = mysqli_query($connect, $query);
      $output .= '
      <div class="table-responsive">
           <table class="table table-bordered">';
      while($row = mysqli_fetch_array($result))
      {
           $output .= '
                <tr>
                     <td width="30%"><label>Name</label></td>
                     <td width="70%">'.$row["name"].'</td>
                </tr>
                <tr>
                     <td width="30%"><label>Address</label></td>
                     <td width="70%">'.$row["address"].'</td>
                </tr>
                <tr>
                     <td width="30%"><label>Gender</label></td>
                     <td width="70%">'.$row["gender"].'</td>
                </tr>
                <tr>
                     <td width="30%"><label>Designation</label></td>
                     <td width="70%">'.$row["designation"].'</td>
                </tr>
                <tr>
                     <td width="30%"><label>Age</label></td>
                     <td width="70%">'.$row["age"].' Year</td>
                </tr>
           ';
      }
      $output .= '
           </table>
      </div>
      ';
      echo $output;
 }
 ?>
